20190313：121 张 barchart，只有 rectangle 的标注数据
20190314：121 张 barchart，rectangle + axis + legend